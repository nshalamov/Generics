package GenericBox;

public class Box<T extends Comparable<T>> {
    private final T value;

    public Box(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public int compareTo(T other) {
        return this.getValue().compareTo(other);
    }

    public String toString() {
        return this.value.getClass().getName() + ": " + value;
    }
}