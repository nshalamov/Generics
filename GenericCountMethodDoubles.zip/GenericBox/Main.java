package GenericBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());
        List<Box<Double>> boxes = new ArrayList<>();

        while(n-- > 0) {
            double input = Double.parseDouble(scan.nextLine());
            Box<Double> box = new Box<>(input);
            boxes.add(box);
        }
        double checker = Double.parseDouble(scan.nextLine());
        int biggerElements = compare(boxes, checker);
        System.out.println(biggerElements);
    }

    private static <T extends Comparable<T>> int compare(List<Box<T>> boxes, T checker) {
        int counter = 0;
        for (Box<T> box : boxes) {
            if (box.getValue().compareTo(checker) > 0) {
                counter++;
            }
        }
        return counter;
    }
}