package GenericBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());
        List<Box<String>> boxes = new ArrayList<>();

        while(n-- > 0) {
            String input = scan.nextLine();
            Box<String> box = new Box<>(input);
            boxes.add(box);
        }
        String checker = scan.nextLine();
        int biggerElements = compare(boxes, checker);
        System.out.println(biggerElements);
    }

    private static int compare(List<Box<String>> boxes, String checker) {
        int counter = 0;
        for (Box<String> box : boxes) {
            if (box.getValue().compareTo(checker) > 0) {
                counter++;
            }
        }
        return counter;
    }
}