package CustomList;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<String> ferenz = new ArrayList<>();
        String input = scan.nextLine();

        while (!input.equals("END")) {
            String[] tokens = input.split("\\s+");
            switch (tokens[0]) {
                case "Add":
                    ferenz.add(tokens[1]);
                    break;
                case "Remove":
                    ferenz.remove(Integer.parseInt(tokens[1]));
                    break;
                case "Contains":
                    String s = tokens[1];
                    if (ferenz.contains(s)) {
                        System.out.println(ferenz.contains(s));
                    }
                    break;
                case "Swap":
                    ferenz.swap(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
                    break;
                case "Greater":
                    System.out.println(ferenz.countGreaterThan(tokens[1]));
                    break;
                case "Max":
                    if (ferenz.getMax() != null) {
                        System.out.println(ferenz.getMax());
                    }
                    break;
                case "Min":
                    if (ferenz.getMin() != null) {
                        System.out.println(ferenz.getMin());
                    }
                    break;
                case "Print":
                    ferenz.print();
                    break;
                case "Sort":
                    ferenz.sort();
                    break;
            }
            input = scan.nextLine();
        }
    }
}
