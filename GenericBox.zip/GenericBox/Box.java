package GenericBox;

public class Box<T> {
    private T value;

    public Box(T value) {
        this.value = value;
    }

    public String toString() {
        return this.value.getClass().getName() + ": " + value;
    }
}
