package GenericBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        List<Box> boxes = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String input = scan.nextLine();
            Box<String> box = new Box<>(input);
            boxes.add(box);
        }

        String[] command = scan.nextLine().split("\\s+");
        int firstIndex = Integer.parseInt(command[0]);
        int secondIndex = Integer.parseInt(command[1]);

        swapIndexes(boxes, firstIndex, secondIndex);

        for (Box box : boxes) {
            System.out.println(box.toString());
        }
    }

    private static void swapIndexes(List<Box> boxes, int firstIndex, int secondIndex) {
        Box swapping = boxes.get(firstIndex);
        boxes.set(firstIndex, boxes.get(secondIndex));
        boxes.set(secondIndex, swapping);
    }
}